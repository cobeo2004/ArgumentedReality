import SwiftUI

struct AlternativeView: View {
    var body: some View {
        Text("Your device isn't yet supported !")
    }
}

struct AlternativeView_Previews: PreviewProvider {
    static var previews: some View {
        AlternativeView()
    }
}
